package com.edx.microservicios;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Ad4MicroserviciosApplicationTests {

	@Test
	void contextLoads() {
	}

}
