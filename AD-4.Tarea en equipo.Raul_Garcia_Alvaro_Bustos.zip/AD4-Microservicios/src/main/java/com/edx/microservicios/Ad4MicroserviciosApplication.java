package com.edx.microservicios;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Ad4MicroserviciosApplication {

	public static void main(String[] args) {
		SpringApplication.run(Ad4MicroserviciosApplication.class, args);
	}

}
